 export function add(a,b){
    return a+b;
 }
 

 export let person={
    name:"zakia",

    grade:"three",
     engine(){
        console.log("hi")
    }
 }
//  Task 4
export default person




